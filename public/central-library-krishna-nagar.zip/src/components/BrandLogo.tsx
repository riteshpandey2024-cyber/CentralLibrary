interface BrandLogoProps {
  variant?: 'navbar' | 'stacked';
  light?: boolean;
}

export function BrandLogo({ variant = 'navbar', light = false }: BrandLogoProps) {
  const primaryColor = light ? 'text-[#F8F6F0]' : 'text-[#101D35]';
  const subColor = light ? 'text-[#D4AD62]' : 'text-[#737B89]';
  const strokeColor = light ? '#D4AD62' : '#101D35';
  const accentColor = '#D4AD62';

  if (variant === 'navbar') {
    return (
      <span className={`inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 ${primaryColor}`}>
        <svg
          width="28"
          height="28"
          viewBox="0 0 32 32"
          fill="none"
          aria-hidden="true"
          className="shrink-0"
        >
          <path
            d="M4 8.5C4 7.39543 4.89543 6.5 6 6.5H13.5C14.8807 6.5 16 7.61929 16 9V25.5C16 24.3954 15.1046 23.5 14 23.5H6C4.89543 23.5 4 22.6046 4 21.5V8.5Z"
            stroke={strokeColor}
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
          <path
            d="M28 8.5C28 7.39543 27.1046 6.5 26 6.5H18.5C17.1193 6.5 16 7.61929 16 9V25.5C16 24.3954 16.8954 23.5 18 23.5H26C27.1046 23.5 28 22.6046 28 21.5V8.5Z"
            stroke={strokeColor}
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
          <path d="M16 4V26.5" stroke={accentColor} strokeWidth="1.75" strokeLinecap="round" />
        </svg>
        <span className="font-serif text-base sm:text-lg font-semibold tracking-tight whitespace-nowrap shrink-0">
          Central Library Krishna Nagar
        </span>
      </span>
    );
  }

  return (
    <div className="inline-flex items-center gap-3 shrink-0">
      <svg
        width="36"
        height="36"
        viewBox="0 0 32 32"
        fill="none"
        aria-hidden="true"
        className="shrink-0"
      >
        <path
          d="M4 8.5C4 7.39543 4.89543 6.5 6 6.5H13.5C14.8807 6.5 16 7.61929 16 9V25.5C16 24.3954 15.1046 23.5 14 23.5H6C4.89543 23.5 4 22.6046 4 21.5V8.5Z"
          stroke={strokeColor}
          strokeWidth="1.75"
          strokeLinejoin="round"
        />
        <path
          d="M28 8.5C28 7.39543 27.1046 6.5 26 6.5H18.5C17.1193 6.5 16 7.61929 16 9V25.5C16 24.3954 16.8954 23.5 18 23.5H26C27.1046 23.5 28 22.6046 28 21.5V8.5Z"
          stroke={strokeColor}
          strokeWidth="1.75"
          strokeLinejoin="round"
        />
        <path d="M16 4V26.5" stroke={accentColor} strokeWidth="1.75" strokeLinecap="round" />
      </svg>
      <div className="flex flex-col leading-tight">
        <span className={`font-serif text-base font-bold tracking-wider ${primaryColor}`}>
          CENTRAL LIBRARY
        </span>
        <span className={`text-[11px] font-semibold tracking-[0.22em] ${subColor}`}>
          KRISHNA NAGAR
        </span>
      </div>
    </div>
  );
}
