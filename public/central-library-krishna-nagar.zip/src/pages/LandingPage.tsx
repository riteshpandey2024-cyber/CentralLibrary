import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Armchair,
  BookOpen,
  Check,
  Clock,
  Droplets,
  ExternalLink,
  Lightbulb,
  Mail,
  MapPin,
  Megaphone,
  Phone,
  Plug,
  ShieldCheck,
  Sparkles,
  VolumeX,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import { Navbar } from '../components/Navbar.tsx';
import { Footer } from '../components/Footer.tsx';
import { ResilientImage } from '../components/ResilientImage.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiRequest } from '../lib/api.ts';
import type { GalleryImage, PublicSiteData } from '../types.ts';

const HERO_IMAGE = '/src/assets/images/hero_library_interior_1794827886144.jpg';
const ABOUT_IMAGE = '/src/assets/images/about_reading_hall_1794827885552.jpg';

function FacilityIcon({ name }: { name: string }) {
  const props = { className: 'w-5 h-5 text-[#101D35]' };
  switch (name) {
    case 'Armchair':
      return <Armchair {...props} />;
    case 'VolumeX':
      return <VolumeX {...props} />;
    case 'Lightbulb':
      return <Lightbulb {...props} />;
    case 'Plug':
      return <Plug {...props} />;
    case 'Droplets':
      return <Droplets {...props} />;
    case 'Sparkles':
      return <Sparkles {...props} />;
    case 'ShieldCheck':
      return <ShieldCheck {...props} />;
    default:
      return <BookOpen {...props} />;
  }
}

export function LandingPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [siteData, setSiteData] = useState<PublicSiteData | null>(null);
  const [loading, setLoading] = useState(true);
  const [galleryCategory, setGalleryCategory] = useState('All');
  const [lightboxImage, setLightboxImage] = useState<GalleryImage | null>(null);

  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    mobile: '',
    subject: 'Membership Enquiry',
    message: '',
  });
  const [submittingContact, setSubmittingContact] = useState(false);
  const [contactSubmitted, setContactSubmitted] = useState(false);

  useEffect(() => {
    apiRequest<PublicSiteData>('/api/public/site-data')
      .then((data) => setSiteData(data))
      .catch(() => showToast('Unable to load library information.', 'error'))
      .finally(() => setLoading(false));
  }, [showToast]);

  const galleryCategories = useMemo(() => {
    if (!siteData) return ['All'];
    const cats = Array.from(new Set(siteData.gallery.map((g) => g.category)));
    return ['All', ...cats];
  }, [siteData]);

  const filteredGallery = useMemo(() => {
    if (!siteData) return [];
    if (galleryCategory === 'All') return siteData.gallery;
    return siteData.gallery.filter((g) => g.category === galleryCategory);
  }, [siteData, galleryCategory]);

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name.trim() || !contactForm.email.trim() || !contactForm.message.trim()) {
      showToast('Please enter your name, email address, and message.', 'error');
      return;
    }
    setSubmittingContact(true);
    try {
      const res = await apiRequest<{ message: string }>('/api/contact', {
        method: 'POST',
        body: JSON.stringify(contactForm),
      });
      showToast(res.message, 'success');
      setContactSubmitted(true);
      setContactForm({
        name: '',
        email: '',
        mobile: '',
        subject: 'Membership Enquiry',
        message: '',
      });
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Unable to send enquiry.', 'error');
    } finally {
      setSubmittingContact(false);
    }
  };

  const settings = siteData?.settings;
  const operatingHours = settings?.operatingHours || '7:00 AM – 10:00 PM';
  const address =
    settings?.address ||
    '1 A, Gopal Nagar, Krishna Nagar, Alambagh, Lucknow, Uttar Pradesh – 226023, India';
  const mapsUrl =
    settings?.googleMapsUrl ||
    'https://maps.google.com/?q=1+A,+Gopal+Nagar,+Krishna+Nagar,+Alambagh,+Lucknow,+Uttar+Pradesh+226023';

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F0] text-[#101D35]">
      <Navbar />

      <main className="flex-1">
        {/* HERO SECTION */}
        <section className="relative bg-[#101D35] text-[#F8F6F0] overflow-hidden">
          <div className="absolute inset-0">
            <ResilientImage
              src={HERO_IMAGE}
              alt="Central Library Krishna Nagar study hall with walnut desks and brass lamps"
              className="w-full h-full object-cover object-center opacity-40"
              fallbackTitle="Central Library Krishna Nagar"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#101D35] via-[#101D35]/88 to-[#101D35]/55" />
          </div>

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-32">
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
              className="max-w-3xl"
            >
              <p className="text-xs sm:text-sm font-medium text-[#D4AD62] tracking-wide mb-4">
                Central Library Krishna Nagar <span aria-hidden="true">·</span> Krishna Nagar, Lucknow{' '}
                <span aria-hidden="true">·</span> Open daily {operatingHours}
              </p>

              <h1
                className="font-serif font-bold text-[#F8F6F0] leading-[1.12] tracking-tight"
                style={{ fontSize: 'clamp(2.25rem, 4.5vw, 3.75rem)', textWrap: 'balance' }}
              >
                {settings?.tagline || 'A Better Space. A Better Focus. A Better Future.'}
              </h1>

              <p className="mt-6 text-base sm:text-lg text-[#D8DFEB] leading-relaxed max-w-2xl">
                Discover a peaceful and disciplined study environment designed for students,
                competitive examination aspirants, and independent learners. Make every study
                session count at Central Library Krishna Nagar.
              </p>

              <div className="mt-9 flex flex-wrap items-center gap-4">
                <a
                  href="#membership"
                  className="inline-flex items-center justify-center px-6 py-3.5 rounded-lg bg-[#D4AD62] text-[#101D35] font-semibold text-sm sm:text-base hover:bg-[#DFBC79] transition-colors whitespace-nowrap shrink-0"
                >
                  Explore Membership
                </a>
                <Link
                  to={user ? (user.role === 'admin' ? '/admin' : '/dashboard') : '/login'}
                  className="inline-flex items-center justify-center px-6 py-3.5 rounded-lg border border-[#F8F6F0]/35 text-[#F8F6F0] font-medium text-sm sm:text-base hover:bg-white/10 transition-colors whitespace-nowrap shrink-0"
                >
                  {user ? 'Go to Portal' : 'Member Login'}
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        {/* KEY HIGHLIGHTS STRIP */}
        <section className="bg-white border-b border-[#E2DFD5]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              <div>
                <h2 className="font-serif text-lg font-semibold text-[#101D35]">
                  Peaceful Study Environment
                </h2>
                <p className="mt-1.5 text-sm text-[#586272] leading-relaxed">
                  Quiet reading halls structured to protect long stretches of uninterrupted focus.
                </p>
              </div>
              <div>
                <h2 className="font-serif text-lg font-semibold text-[#101D35]">
                  Student-Focused Space
                </h2>
                <p className="mt-1.5 text-sm text-[#586272] leading-relaxed">
                  Tailored for competitive exam aspirants, college learners, and self-paced scholars.
                </p>
              </div>
              <div>
                <h2 className="font-serif text-lg font-semibold text-[#101D35]">
                  Disciplined Study Culture
                </h2>
                <p className="mt-1.5 text-sm text-[#586272] leading-relaxed">
                  Shared respect, clear etiquette, and orderly seating across every study session.
                </p>
              </div>
              <div>
                <h2 className="font-serif text-lg font-semibold text-[#101D35]">
                  Convenient Daily Hours
                </h2>
                <p className="mt-1.5 text-sm text-[#586272] leading-relaxed">
                  Open daily from <span className="font-medium text-[#101D35]">{operatingHours}</span>{' '}
                  to fit morning and evening routines.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* PUBLISHED ANNOUNCEMENTS BANNER (ONLY IF ADMIN PUBLISHED) */}
        {siteData && siteData.announcements.length > 0 && (
          <section className="bg-[#EAF1F8] border-b border-[#D5E1EE]">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start sm:items-center gap-3">
                  <Megaphone className="w-4 h-4 text-[#101D35] shrink-0 mt-0.5 sm:mt-0" />
                  <div className="text-sm text-[#101D35]">
                    <span className="font-semibold">
                      {siteData.announcements[0].title}:
                    </span>{' '}
                    <span className="text-[#2D3B50]">{siteData.announcements[0].content}</span>
                  </div>
                </div>
                <span className="text-xs text-[#586272] tabular-nums shrink-0">
                  {new Date(siteData.announcements[0].publishedAt).toLocaleDateString('en-IN')}
                </span>
              </div>
            </div>
          </section>
        )}

        {/* ABOUT SECTION */}
        <section id="about" className="py-16 sm:py-24 bg-[#F8F6F0]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
              <div className="lg:col-span-6">
                <div className="h-full min-h-[300px] rounded-xl overflow-hidden border border-[#E2DFD5] bg-white">
                  <ResilientImage
                    src={ABOUT_IMAGE}
                    alt="Quiet academic reading room at Central Library Krishna Nagar"
                    className="w-full h-full object-cover"
                    fallbackTitle="Reading Hall Atmosphere"
                  />
                </div>
              </div>
              <div className="lg:col-span-6 flex flex-col justify-center py-2">
                <p className="text-xs font-semibold tracking-wider text-[#BA9245] uppercase">
                  About the Library
                </p>
                <h2
                  className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#101D35] leading-tight"
                  style={{ textWrap: 'balance' }}
                >
                  {settings?.aboutHeading || 'A Space Designed for Serious Learning'}
                </h2>
                <p className="mt-5 text-base text-[#374151] leading-relaxed">
                  {settings?.aboutBody ||
                    'Central Library Krishna Nagar provides a dedicated environment for students and independent learners who value concentration, consistency, and academic growth. Our aim is to make focused learning more comfortable, organized, and accessible.'}
                </p>
                {settings?.aboutSecondaryBody && (
                  <p className="mt-4 text-base text-[#586272] leading-relaxed">
                    {settings.aboutSecondaryBody}
                  </p>
                )}
                <div className="mt-8 pt-6 border-t border-[#E2DFD5] grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm">
                  <div>
                    <h3 className="font-semibold text-[#101D35]">Focused Atmosphere</h3>
                    <p className="mt-1 text-[#586272]">
                      Free from household interruptions, built around steady daily study habits.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#101D35]">Student Convenience</h3>
                    <p className="mt-1 text-[#586272]">
                      Accessible Krishna Nagar location with transparent rules and organized seating.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FACILITIES & AMENITIES */}
        <section id="facilities" className="py-16 sm:py-24 bg-white border-y border-[#E2DFD5]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold tracking-wider text-[#BA9245] uppercase">
                Facilities &amp; Amenities
              </p>
              <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#101D35]">
                Essential Comforts for Long Study Hours
              </h2>
              <p className="mt-3 text-base text-[#586272]">
                Available amenities confirmed and maintained by the Central Library Krishna Nagar
                administration.
              </p>
            </div>

            {loading ? (
              <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="h-44 rounded-xl bg-[#F8F6F0] animate-pulse" />
                ))}
              </div>
            ) : siteData && siteData.facilities.length > 0 ? (
              <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {siteData.facilities.map((facility) => (
                  <div
                    key={facility.id}
                    className="p-6 rounded-xl border border-[#E2DFD5] bg-[#FDFCF9] hover:border-[#D4AD62] transition-colors"
                  >
                    <div className="w-10 h-10 rounded-lg bg-[#EAF1F8] flex items-center justify-center mb-4">
                      <FacilityIcon name={facility.iconName} />
                    </div>
                    <h3 className="font-serif text-lg font-semibold text-[#101D35]">
                      {facility.title}
                    </h3>
                    <p className="mt-2 text-sm text-[#586272] leading-relaxed">
                      {facility.description}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-8 text-sm text-[#586272]">
                Confirmed facilities will appear here once published by administration.
              </p>
            )}
          </div>
        </section>

        {/* STUDY ENVIRONMENT GALLERY */}
        <section id="gallery" className="py-16 sm:py-24 bg-[#F8F6F0]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <p className="text-xs font-semibold tracking-wider text-[#BA9245] uppercase">
                  Study Environment Gallery
                </p>
                <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#101D35]">
                  Inside Our Study Spaces
                </h2>
              </div>

              {galleryCategories.length > 1 && (
                <div className="flex flex-wrap gap-1.5 p-1 bg-white border border-[#E2DFD5] rounded-lg">
                  {galleryCategories.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setGalleryCategory(cat)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        galleryCategory === cat
                          ? 'bg-[#101D35] text-[#F8F6F0]'
                          : 'text-[#586272] hover:text-[#101D35]'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredGallery.map((item, idx) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setLightboxImage(item)}
                  className={`group text-left rounded-xl overflow-hidden border border-[#E2DFD5] bg-white hover:border-[#101D35] transition-colors cursor-pointer ${
                    idx === 0 && filteredGallery.length >= 4 ? 'lg:col-span-2' : ''
                  }`}
                >
                  <div
                    className={`overflow-hidden bg-[#172943] ${
                      idx === 0 && filteredGallery.length >= 4 ? 'aspect-[16/9]' : 'aspect-[4/3]'
                    }`}
                  >
                    <ResilientImage
                      src={item.imageUrl}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                      fallbackTitle={item.title}
                    />
                  </div>
                  <div className="p-5">
                    <div className="text-xs text-[#737B89]">{item.category}</div>
                    <h3 className="mt-1 font-serif text-lg font-semibold text-[#101D35]">
                      {item.title}
                    </h3>
                    {item.caption && (
                      <p className="mt-1 text-sm text-[#586272] leading-relaxed">{item.caption}</p>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* MEMBERSHIP SECTION */}
        <section id="membership" className="py-16 sm:py-24 bg-[#101D35] text-[#F8F6F0]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold tracking-wider text-[#D4AD62] uppercase">
                Membership Plans
              </p>
              <h2
                className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#F8F6F0]"
                style={{ textWrap: 'balance' }}
              >
                Choose a Membership That Fits Your Study Routine
              </h2>
              <p className="mt-3 text-base text-[#C7CEDB]">
                Select a study duration below to apply for membership or request current fee details
                from the library administration.
              </p>
            </div>

            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {(siteData?.plans || []).map((plan) => (
                <div
                  key={plan.id}
                  className="flex flex-col justify-between p-6 rounded-xl bg-[#172943] border border-[#253D61] hover:border-[#D4AD62] transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs text-[#D4AD62] font-medium">
                      <span>{plan.durationLabel}</span>
                      <span aria-hidden="true">·</span>
                      <span>{plan.isAvailable ? 'Accepting Applications' : 'Currently Closed'}</span>
                    </div>
                    <h3 className="mt-2 font-serif text-xl font-bold text-white">{plan.name}</h3>
                    <div className="mt-4 pb-4 border-b border-[#253D61]">
                      {plan.priceInr !== null && plan.priceInr > 0 ? (
                        <div className="flex items-baseline gap-1">
                          <span className="font-serif text-3xl font-bold text-[#D4AD62] tabular-nums">
                            &#8377;{plan.priceInr.toLocaleString('en-IN')}
                          </span>
                          <span className="text-xs text-[#C7CEDB]">/ {plan.durationLabel}</span>
                        </div>
                      ) : (
                        <p className="text-sm font-medium text-[#D4AD62]">
                          Fee configured by Administrator · Enquire at Desk
                        </p>
                      )}
                    </div>

                    <p className="mt-4 text-sm text-[#C7CEDB] leading-relaxed">
                      {plan.description}
                    </p>

                    {plan.facilitiesIncluded.length > 0 && (
                      <ul className="mt-5 space-y-2.5 text-sm text-[#E5E9F0]">
                        {plan.facilitiesIncluded.map((feat, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <Check className="w-4 h-4 text-[#D4AD62] shrink-0 mt-0.5" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  <div className="mt-8 pt-4 border-t border-[#253D61]">
                    {plan.termsAndConditions && (
                      <p className="text-xs text-[#A3AEC2] mb-4 leading-relaxed">
                        {plan.termsAndConditions}
                      </p>
                    )}
                    <button
                      type="button"
                      disabled={!plan.isAvailable}
                      onClick={() =>
                        navigate(user ? '/dashboard?tab=membership' : `/register?plan=${plan.id}`)
                      }
                      className="w-full py-2.5 px-4 rounded-lg bg-[#D4AD62] text-[#101D35] font-semibold text-sm hover:bg-[#DFBC79] disabled:opacity-50 disabled:cursor-not-allowed transition-colors cursor-pointer"
                    >
                      {plan.isAvailable ? 'Get Membership' : 'Unavailable'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* LIBRARY RULES */}
        <section id="rules" className="py-16 sm:py-24 bg-white border-b border-[#E2DFD5]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold tracking-wider text-[#BA9245] uppercase">
                Code of Conduct
              </p>
              <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#101D35]">
                Library Rules &amp; Study Etiquette
              </h2>
              <p className="mt-3 text-base text-[#586272]">
                Every member upholds a quiet, respectful environment so everyone can study without
                distraction.
              </p>
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {(siteData?.rules || []).map((rule, index) => (
                <div
                  key={rule.id}
                  className="p-6 rounded-xl border border-[#E2DFD5] bg-[#FDFCF9]"
                >
                  <div className="flex items-center justify-between text-xs text-[#737B89] mb-2">
                    <span className="font-mono font-semibold text-[#BA9245] tabular-nums">
                      {String(index + 1).padStart(2, '0')}.
                    </span>
                    <span>{rule.category}</span>
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#101D35]">
                    {rule.title}
                  </h3>
                  <p className="mt-2 text-sm text-[#586272] leading-relaxed">
                    {rule.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CONTACT & LOCATION */}
        <section id="contact" className="py-16 sm:py-24 bg-[#F8F6F0]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
              {/* Location & Details */}
              <div className="lg:col-span-5 space-y-6">
                <div>
                  <p className="text-xs font-semibold tracking-wider text-[#BA9245] uppercase">
                    Contact &amp; Location
                  </p>
                  <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#101D35]">
                    {settings?.libraryName || 'Central Library Krishna Nagar'}
                  </h2>
                </div>

                <div className="space-y-4 text-sm text-[#374151]">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-[#101D35] shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-[#101D35]">Library Address</p>
                      <p className="mt-0.5 text-[#586272] leading-relaxed">{address}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-[#101D35] shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-[#101D35]">Operating Hours</p>
                      <p className="mt-0.5 text-[#586272]">{operatingHours} (Open Daily)</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-[#101D35] shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-[#101D35]">Phone</p>
                      <p className="mt-0.5 text-[#586272] tabular-nums">
                        {settings?.phone ? (
                          <a href={`tel:${settings.phone}`} className="hover:underline">
                            {settings.phone}
                          </a>
                        ) : (
                          'Contact number configurable in Admin Settings — use the enquiry form.'
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Mail className="w-5 h-5 text-[#101D35] shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-[#101D35]">Email</p>
                      <p className="mt-0.5 text-[#586272]">
                        {settings?.email ? (
                          <a href={`mailto:${settings.email}`} className="hover:underline">
                            {settings.email}
                          </a>
                        ) : (
                          'Email configurable in Admin Settings — send an enquiry anytime.'
                        )}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#101D35] text-[#F8F6F0] text-sm font-semibold hover:bg-[#172943] transition-colors"
                  >
                    Get Directions on Google Maps
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>

                <div className="rounded-xl overflow-hidden border border-[#E2DFD5] bg-white h-56">
                  <iframe
                    title="Central Library Krishna Nagar Map"
                    src="https://maps.google.com/maps?q=1+A,+Gopal+Nagar,+Krishna+Nagar,+Alambagh,+Lucknow,+Uttar+Pradesh+226023&output=embed"
                    className="w-full h-full border-0"
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  />
                </div>
              </div>

              {/* Enquiry Form */}
              <div className="lg:col-span-7">
                <div className="bg-white border border-[#E2DFD5] rounded-xl p-6 sm:p-8">
                  <h3 className="font-serif text-2xl font-bold text-[#101D35]">
                    Send an Enquiry
                  </h3>
                  <p className="mt-1.5 text-sm text-[#586272]">
                    Have questions about membership plans, seat availability, or visiting hours?
                    Write to our administration desk.
                  </p>

                  {contactSubmitted && (
                    <div className="mt-4 p-4 rounded-lg bg-emerald-50 border border-emerald-200 text-sm text-emerald-900">
                      Your enquiry has been received by Central Library Krishna Nagar. We will get
                      back to you shortly.
                    </div>
                  )}

                  <form onSubmit={handleContactSubmit} className="mt-6 space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label
                          htmlFor="contact-name"
                          className="block text-sm font-medium text-[#101D35] mb-1.5"
                        >
                          Full Name *
                        </label>
                        <input
                          id="contact-name"
                          type="text"
                          required
                          value={contactForm.name}
                          onChange={(e) =>
                            setContactForm((p) => ({ ...p, name: e.target.value }))
                          }
                          placeholder="Your full name"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm text-[#101D35] focus:outline-none focus:border-[#101D35]"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="contact-mobile"
                          className="block text-sm font-medium text-[#101D35] mb-1.5"
                        >
                          Mobile Number
                        </label>
                        <input
                          id="contact-mobile"
                          type="tel"
                          value={contactForm.mobile}
                          onChange={(e) =>
                            setContactForm((p) => ({ ...p, mobile: e.target.value }))
                          }
                          placeholder="10-digit mobile number"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm text-[#101D35] focus:outline-none focus:border-[#101D35]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label
                          htmlFor="contact-email"
                          className="block text-sm font-medium text-[#101D35] mb-1.5"
                        >
                          Email Address *
                        </label>
                        <input
                          id="contact-email"
                          type="email"
                          required
                          value={contactForm.email}
                          onChange={(e) =>
                            setContactForm((p) => ({ ...p, email: e.target.value }))
                          }
                          placeholder="you@example.com"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm text-[#101D35] focus:outline-none focus:border-[#101D35]"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="contact-subject"
                          className="block text-sm font-medium text-[#101D35] mb-1.5"
                        >
                          Enquiry Topic
                        </label>
                        <select
                          id="contact-subject"
                          value={contactForm.subject}
                          onChange={(e) =>
                            setContactForm((p) => ({ ...p, subject: e.target.value }))
                          }
                          className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm text-[#101D35] focus:outline-none focus:border-[#101D35]"
                        >
                          <option value="Membership Enquiry">Membership Enquiry</option>
                          <option value="Visit & Tour">Schedule a Library Visit</option>
                          <option value="Seat Availability">Seat Availability</option>
                          <option value="General Question">General Question</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="contact-message"
                        className="block text-sm font-medium text-[#101D35] mb-1.5"
                      >
                        Message *
                      </label>
                      <textarea
                        id="contact-message"
                        rows={4}
                        required
                        value={contactForm.message}
                        onChange={(e) =>
                          setContactForm((p) => ({ ...p, message: e.target.value }))
                        }
                        placeholder="Share your study schedule, membership query, or preferred visiting time..."
                        className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm text-[#101D35] focus:outline-none focus:border-[#101D35]"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={submittingContact}
                      className="inline-flex items-center justify-center px-6 py-3 rounded-lg bg-[#101D35] text-[#F8F6F0] text-sm font-semibold hover:bg-[#172943] disabled:opacity-60 transition-colors cursor-pointer"
                    >
                      {submittingContact ? 'Sending Enquiry...' : 'Submit Enquiry'}
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Gallery Lightbox Modal */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#101D35]/85 p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => setLightboxImage(null)}
        >
          <div
            className="bg-white rounded-xl max-w-4xl w-full overflow-hidden border border-[#E2DFD5]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#E2DFD5]">
              <div>
                <p className="text-xs text-[#737B89]">{lightboxImage.category}</p>
                <h3 className="font-serif text-lg font-semibold text-[#101D35]">
                  {lightboxImage.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setLightboxImage(null)}
                className="p-1.5 rounded-lg text-[#737B89] hover:text-[#101D35] hover:bg-[#F8F6F0]"
                aria-label="Close image preview"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="bg-[#101D35] max-h-[70vh] overflow-hidden flex items-center justify-center">
              <ResilientImage
                src={lightboxImage.imageUrl}
                alt={lightboxImage.title}
                className="w-full max-h-[70vh] object-contain"
                fallbackTitle={lightboxImage.title}
              />
            </div>
            {lightboxImage.caption && (
              <p className="px-5 py-3.5 text-sm text-[#4A5362]">{lightboxImage.caption}</p>
            )}
          </div>
        </div>
      )}

      <Footer settings={settings} />
    </div>
  );
}
