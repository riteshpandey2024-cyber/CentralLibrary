import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Check, Eye, EyeOff } from 'lucide-react';
import { Navbar } from '../components/Navbar.tsx';
import { Footer } from '../components/Footer.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiRequest } from '../lib/api.ts';
import type { MembershipPlan, User } from '../types.ts';

export function RegisterPage() {
  const { setAuthUser, refreshAuth } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const preselectedPlanId = searchParams.get('plan') || '';

  const [plans, setPlans] = useState<MembershipPlan[]>([]);
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [form, setForm] = useState({
    fullName: '',
    mobile: '',
    email: '',
    password: '',
    confirmPassword: '',
    category: 'Competitive Exam Aspirant',
    institutionName: '',
    courseOrExam: '',
    planId: preselectedPlanId,
    privacyAccepted: false,
    termsAccepted: false,
  });

  useEffect(() => {
    apiRequest<MembershipPlan[]>('/api/membership-plans')
      .then((list) => {
        setPlans(list);
        if (!form.planId && list.length > 0) {
          setForm((prev) => ({ ...prev, planId: preselectedPlanId || list[0].id }));
        }
      })
      .catch(() => {});
  }, [preselectedPlanId, form.planId]);

  const passwordChecks = {
    length: form.password.length >= 8,
    upper: /[A-Z]/.test(form.password),
    lower: /[a-z]/.test(form.password),
    number: /[0-9]/.test(form.password),
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) {
      showToast('Passwords do not match.', 'error');
      return;
    }
    if (!form.privacyAccepted || !form.termsAccepted) {
      showToast('Please accept the Privacy Policy and Terms & Conditions.', 'error');
      return;
    }

    setSubmitting(true);
    try {
      const res = await apiRequest<{ message: string; user: User }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(form),
      });
      setAuthUser(res.user);
      await refreshAuth();
      showToast(res.message, 'success');
      navigate('/dashboard');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Unable to submit registration.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F0]">
      <Navbar />
      <main className="flex-1 py-12 sm:py-16 px-4 sm:px-6">
        <div className="max-w-2xl mx-auto bg-white border border-[#E2DFD5] rounded-xl p-6 sm:p-10 shadow-sm">
          <p className="text-xs font-semibold tracking-wider text-[#BA9245] uppercase">
            Central Library Krishna Nagar
          </p>
          <h1 className="mt-1.5 font-serif text-3xl font-bold text-[#101D35]">
            Member Registration
          </h1>
          <p className="mt-2 text-sm text-[#586272] leading-relaxed">
            Create your study library account. After submission, your membership status starts as
            Pending until reviewed by our administrator.
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label
                  htmlFor="reg-name"
                  className="block text-sm font-medium text-[#101D35] mb-1.5"
                >
                  Full Name *
                </label>
                <input
                  id="reg-name"
                  type="text"
                  required
                  value={form.fullName}
                  onChange={(e) => setForm((p) => ({ ...p, fullName: e.target.value }))}
                  placeholder="Enter your full name"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm focus:outline-none focus:border-[#101D35]"
                />
              </div>

              <div>
                <label
                  htmlFor="reg-mobile"
                  className="block text-sm font-medium text-[#101D35] mb-1.5"
                >
                  Mobile Number *
                </label>
                <input
                  id="reg-mobile"
                  type="tel"
                  required
                  value={form.mobile}
                  onChange={(e) => setForm((p) => ({ ...p, mobile: e.target.value }))}
                  placeholder="10-digit mobile number"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm tabular-nums focus:outline-none focus:border-[#101D35]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label
                  htmlFor="reg-email"
                  className="block text-sm font-medium text-[#101D35] mb-1.5"
                >
                  Email Address *
                </label>
                <input
                  id="reg-email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
                  placeholder="you@example.com"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm focus:outline-none focus:border-[#101D35]"
                />
              </div>

              <div>
                <label
                  htmlFor="reg-category"
                  className="block text-sm font-medium text-[#101D35] mb-1.5"
                >
                  Student / Learner Category *
                </label>
                <select
                  id="reg-category"
                  value={form.category}
                  onChange={(e) => setForm((p) => ({ ...p, category: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm focus:outline-none focus:border-[#101D35]"
                >
                  <option value="Competitive Exam Aspirant">Competitive Exam Aspirant</option>
                  <option value="College Student">College Student</option>
                  <option value="School Student">School Student</option>
                  <option value="Independent Learner">Independent Learner</option>
                  <option value="Working Professional">Working Professional</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label
                  htmlFor="reg-inst"
                  className="block text-sm font-medium text-[#101D35] mb-1.5"
                >
                  Institution Name (optional)
                </label>
                <input
                  id="reg-inst"
                  type="text"
                  value={form.institutionName}
                  onChange={(e) => setForm((p) => ({ ...p, institutionName: e.target.value }))}
                  placeholder="University, College, or Coaching"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm focus:outline-none focus:border-[#101D35]"
                />
              </div>

              <div>
                <label
                  htmlFor="reg-course"
                  className="block text-sm font-medium text-[#101D35] mb-1.5"
                >
                  Course / Exam Preparation (optional)
                </label>
                <input
                  id="reg-course"
                  type="text"
                  value={form.courseOrExam}
                  onChange={(e) => setForm((p) => ({ ...p, courseOrExam: e.target.value }))}
                  placeholder="e.g., UPSC, SSC, NEET, B.Tech, CA"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm focus:outline-none focus:border-[#101D35]"
                />
              </div>
            </div>

            {plans.length > 0 && (
              <div>
                <label
                  htmlFor="reg-plan"
                  className="block text-sm font-medium text-[#101D35] mb-1.5"
                >
                  Preferred Membership Plan
                </label>
                <select
                  id="reg-plan"
                  value={form.planId}
                  onChange={(e) => setForm((p) => ({ ...p, planId: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm focus:outline-none focus:border-[#101D35]"
                >
                  {plans.map((pl) => (
                    <option key={pl.id} value={pl.id}>
                      {pl.name} ({pl.durationLabel})
                      {pl.priceInr !== null && pl.priceInr > 0
                        ? ` — ₹${pl.priceInr.toLocaleString('en-IN')}`
                        : ' — Fee set by Desk'}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label
                  htmlFor="reg-pass"
                  className="block text-sm font-medium text-[#101D35] mb-1.5"
                >
                  Password *
                </label>
                <div className="relative">
                  <input
                    id="reg-pass"
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={form.password}
                    onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
                    placeholder="Create strong password"
                    className="w-full px-3.5 py-2.5 pr-10 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm focus:outline-none focus:border-[#101D35]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#737B89] p-1"
                    aria-label="Toggle password visibility"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label
                  htmlFor="reg-confirm"
                  className="block text-sm font-medium text-[#101D35] mb-1.5"
                >
                  Confirm Password *
                </label>
                <input
                  id="reg-confirm"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={form.confirmPassword}
                  onChange={(e) => setForm((p) => ({ ...p, confirmPassword: e.target.value }))}
                  placeholder="Re-enter password"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#D6D2C7] bg-[#FDFCF9] text-sm focus:outline-none focus:border-[#101D35]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-[#586272]">
              {[
                { ok: passwordChecks.length, label: '8+ characters' },
                { ok: passwordChecks.upper, label: 'Uppercase letter' },
                { ok: passwordChecks.lower, label: 'Lowercase letter' },
                { ok: passwordChecks.number, label: 'Number' },
              ].map((item) => (
                <div
                  key={item.label}
                  className={`flex items-center gap-1.5 ${item.ok ? 'text-emerald-700 font-medium' : ''}`}
                >
                  <Check className={`w-3.5 h-3.5 ${item.ok ? 'opacity-100' : 'opacity-30'}`} />
                  <span>{item.label}</span>
                </div>
              ))}
            </div>

            <div className="space-y-3 pt-2 border-t border-[#E2DFD5] text-sm text-[#4A5362]">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.privacyAccepted}
                  onChange={(e) => setForm((p) => ({ ...p, privacyAccepted: e.target.checked }))}
                  className="mt-1 rounded border-[#D6D2C7]"
                />
                <span>
                  I consent to the{' '}
                  <Link to="/privacy" target="_blank" className="text-[#101D35] underline">
                    Privacy Policy
                  </Link>{' '}
                  for library membership administration.
                </span>
              </label>

              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.termsAccepted}
                  onChange={(e) => setForm((p) => ({ ...p, termsAccepted: e.target.checked }))}
                  className="mt-1 rounded border-[#D6D2C7]"
                />
                <span>
                  I accept the{' '}
                  <Link to="/terms" target="_blank" className="text-[#101D35] underline">
                    Terms and Conditions
                  </Link>{' '}
                  and agree to abide by the Library Rules.
                </span>
              </label>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 px-4 rounded-lg bg-[#101D35] text-[#F8F6F0] text-sm font-semibold hover:bg-[#172943] disabled:opacity-60 transition-colors cursor-pointer"
            >
              {submitting ? 'Submitting Registration...' : 'Submit Membership Application'}
            </button>
          </form>

          <p className="mt-6 text-sm text-[#586272] text-center">
            Already registered?{' '}
            <Link to="/login" className="font-semibold text-[#101D35] hover:underline">
              Member Login
            </Link>
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
